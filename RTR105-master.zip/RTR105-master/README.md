# RTR105
Datormacību kursa elektroniskā klade

<b>BASH</b>

<b>"VirtualBox --startvm XP"</b> - Startē VM ar XP

<b>"quartus"</b> - Atver Intel Prime Prime Software

<b>"firefox &"</b> - Atver Firefox internetpārlūk program

<b>"uname"</b> - Parāda tavu operētājsistēmas(OS) nosaukumu

<b>"clear"</b> - Notīra ekrānu Terminal

<b>"uname -r"</b> - Parāda OS detalizētāku nosaukumu

<b>"uname -a"</b> - Parāda OS vēl detalizētāku nosaukumu

<b>"history"</b> - Parāda visas iepriekš ievadītās komandas

<b>"echo $0"</b> - Parāda ar kādu dialektu lietotājs strādā

<b>"clear"</b> - Notīra ekrānu Terminal

<b>"man uname"</b> - Izkaidro ko komanda "uname" dara/nozīmē

<b>"man man"</b> - Izkaidro ko komanda "man" dara/nozīmē

<b>"whoami"</b> - Parāda, kas pašlai lieot Terminal

<b>"who"</b> - Parāda, visus kopējos lietotājus, kuri ir pieslēgušies

<b>"pwd"</b> - Parāda direktoriju, kurā pašlaik tu strādā

<b>"man pwd"</b> - Izkaidro ko komanda "pwd" dara/nozīmē

<b>"ls"</b> - Parāda visas direktorijas, kurai tev ir pieeja tagad esošajā direktorijā

<b>"ls -l"</b> - Parāda kadas ir privilēģijas katram lietotājam katrai direktorijai

<b>"ls -a"</b> - Parāda arī apslēptās direktorijas, kuras sākas ar "."

<b>"ls-la"</b> - "-l" un "-a" apvienojums

<b>"history"</b> - Parāda visas iepriekš ievadītās komandas

<b>"history > history_20180904.txt"</b> - Ieraksta visas iepriekš ievadītās komondas .txt failā

<b>"cd"</b> - Maina direktoriju

<b>"mkdir"</b> - Uztaisa jaunu direktoriju (Mapi)

<b>"rmdir"</b> - Izdzēš direktoriju (mapi), kura ir tuksa

<b>"rm"</b> - Izdzēš direktoriju (mapi), pat ja tā satur failus/apakš direktorijas (mapes)

<b>"echo "Teksts" > fails1.txt"</b> - Tekstu "Teksts" ieraksta .txt failā

<b>"cat"</b> - Var nolasit no .txt faila ierakstīto informāciju

<b>"echo "Cits Teksts" >> fails1.txt"</b> - ">>" papildina .txt failu ar ar "" ieraktīto tekstu nākamajā rindiņā

<b>"chmod"</b> - Maina privilēģinas noteiktiem failiem vai direktorijām

<b>"nano"</b> - Teksta editors Linux terminālī

<b>"cp"</b> - kopē failu no vienas direktorijas uz otru

<b>"mv"</b> - Pārvieto failu no vienas direktorijas uz otru

<b>"echo -e "mkdir Mape\ncd Mape" > create_in.sh"</b> - komandas ieraksta skriptā

<b>"chmod 764"</b> - Nomaina faila privilēģijas

<b>"$PATH"</b> - parāda current PATH

<b>"PATH="</b> - Set a new PATH

<b>"git clone"</b> - Downloads GitHub repository

<b>PYTHON</b>

<b>"vars()"</b> - parāda visas komandas

<b>"type()"</b> - parāda kas par datu tipu ir mainīgais

<b>__doc__</b> - parāda dokumentācijas funkiju\

<b>'''</b>
          - iekomente bloku
<b>'''</b>

<b>input([prompt])</b> - var ievadit tekstu, ko parada pectam dators

<b>print</b> - Uz datora ekrana izprinte doto mainigo

<b>"ashdbadbs %d"%</b> - vesels skaitlis

<b>"asdasdasd %f"%</b> - dalskaitlis

<b>"asdasdasd %s"%</b> - simbolu rinda

<b>raw_input("asdasdas")</b> - Tiek izmantots prieks simbolu rindas

<b>float()</b> - parveido par float

<b>def asjdnasdjk():</b> - funkcija

