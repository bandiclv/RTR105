Python 2.7.12 (default, Dec  4 2017, 14:50:18) 
[GCC 5.4.0 20160609] on linux2
Type "copyright", "credits" or "license()" for more information.
>>> vars()
{'__builtins__': <module '__builtin__' (built-in)>, '__name__': '__main__', '__doc__': None, '__package__': None}
>>> a = 10
>>> a
10
>>> a = 'skkrrrt'
>>> a
'skkrrrt'
>>> a = 10
>>> 
>>> a
10
>>> type(1)
<type 'int'>
>>> type(a)
<type 'int'>
>>> b = 1.5
>>> type(b)
<type 'float'>
>>> c = 'D'
>>> 
