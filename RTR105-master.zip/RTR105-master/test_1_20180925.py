'''
x = input("Ievadiet skatili: ")

y = x * x

#http://www.cplusplus.com/reference/cstdio/printf/

print(x)
print(y)

print(x, y)

print("'x' vertiba ir = %d"% (x))

print('x vertiba = ', x)

a = 2.25

b = a * a
print(b)
'''

'''
x = input("Ievadi dalskaitli: ")
y = x * x

print("y = %.3f"%(y))
print("respektivi, tu esi ievadijis skaitli: %.4f"%(y))
print("vel atmina tagad ari ir mainigais x = %.7f"% (x))
'''
x = raw_input("Ievadiet simbolu rindu: ")

#can't multiply sequence by non-int of type 'str'
#x = x * x

print("y = %s"%(x))
print("respektivi, tu esi ievadijis skaitli: %s"%(x))

#print("vel atmina tagad ari ir mainigais x = %s"% (x))

